package com.example.inventoryapp_joelgarcia;

import android.app.Activity;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.PopupWindow;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class UserLogin extends AppCompatActivity {

    Activity activity;
    Button LoginButton, RegisterButton;
    EditText Name, Password;
    String NameHolder, PasswordHolder;
    Boolean EmptyHolder;
    PopupWindow popwindow;
    SQLiteDatabase db;
    UsersDatabase handler;
    String TempPassword = "NOT_FOUND" ;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        activity = this;

        LoginButton = findViewById(R.id.signinButton);
        RegisterButton = findViewById(R.id.registerButton);
        Name = findViewById(R.id.editTextName);
        Password = findViewById(R.id.editTextPassword);
        handler = new UsersDatabase(this);

        // Adding click listener to sign in
        LoginButton.setOnClickListener(view -> {
            // Call Login function
            LoginFunction();
        });

        // Adding click listener to register
        RegisterButton.setOnClickListener(view -> {
            // Opening new RegisterActivity using intent on forgotPasswordButton click.
            Intent intent = new Intent(UserLogin.this, UserRegister.class);
            startActivity(intent);
        });

    }

    // Login function
    public void LoginFunction() {
        String message = CheckEditTextNotEmpty();

        if(!EmptyHolder) {
            // Opening SQLite database write permission
            db = handler.getWritableDatabase();

            // Adding search name query to cursor
            Cursor cursor = db.query(UsersDatabase.TABLE_NAME, null, " " + UsersDatabase.COLUMN_1_NAME + "=?", new String[]{NameHolder}, null, null, null);

            while (cursor.moveToNext()) {
                if (cursor.isFirst()) {
                    cursor.moveToFirst();

                    // Storing Password associated with entered name
                    TempPassword = cursor.getString(cursor.getColumnIndex(UsersDatabase.COLUMN_2_PASSWORD));

                    // Closing cursor.
                    cursor.close();
                }
            }
            handler.close();

            // Calling method to check final result
            CheckFinalResult();
        } else {
            //If any of login EditText empty then this block will be executed.
            Toast.makeText(UserLogin.this, message, Toast.LENGTH_LONG).show();
        }
    }

    // Checking editText fields are not empty.
    public String CheckEditTextNotEmpty() {
        // Getting value from fields and storing into string variable
        String message = "";
        NameHolder = Name.getText().toString().trim();
        PasswordHolder = Password.getText().toString().trim();

        if (NameHolder.isEmpty()){
            Name.requestFocus();
            EmptyHolder = true;
            message = "Username  is Empty";
        } else if (PasswordHolder.isEmpty()){
            Password.requestFocus();
            EmptyHolder = true;
            message = "User Password is Empty";
        } else {
            EmptyHolder = false;
        }
        return message;
    }

    // Checking entered password from SQLite database name associated password
    public void CheckFinalResult(){
        if(TempPassword.equalsIgnoreCase(PasswordHolder)) {
            Toast.makeText(UserLogin.this,"Login Successful",Toast.LENGTH_SHORT).show();

            // Sending Name to ItemsListActivity using intent
            Bundle bundle = new Bundle();
            bundle.putString("user_name", NameHolder);

            // Going to ItemsListActivity after login success message
            Intent intent = new Intent(UserLogin.this, ItemsView.class);
            intent.putExtras(bundle);
            startActivity(intent);

            // Empty editText  after login successful and close database
            EmptyEditTextAfterDataInsert();
        } else {
            // Display error message if credentials are not correct
            Toast.makeText(UserLogin.this,"Incorrect Username or Password\nor User Not Registered",Toast.LENGTH_LONG).show();
        }
        TempPassword = "NOT_FOUND" ;
    }

    // Empty edittext after login successful
    public void EmptyEditTextAfterDataInsert() {
        Name.getText().clear();
        Password.getText().clear();
    }

}
